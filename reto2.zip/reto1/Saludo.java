package mx.utng.reto1;

public class Saludo {
    
    public static void main(String[] args){
        System.out.println("¡Hola Josue!");
    }
}
