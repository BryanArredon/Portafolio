public class saludoo {
    public static void main(String[] args){
        System.out.println(x:"hola tacho");
        

    }
}
