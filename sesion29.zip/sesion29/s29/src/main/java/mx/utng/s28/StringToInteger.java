package mx.utng.s28;

@FunctionalInterface
public interface StringToInteger {
    Integer convertir(String s);
    

    

    
}
