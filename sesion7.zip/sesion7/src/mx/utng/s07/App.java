public class App{
    public satatic void main(String[] args) throws Excepcion {
        //crear objetos necesarios
        Menu menu = new Menu();
        Lector lector = new Lector();
        ListaTareas lista = new ListaTareas;
        
    }
}