package mx.utng.s07;

import java.util.Scanner;
public class lector {
    private Scanner scanner = new Scanner(System.in);
    public byte leerOpcion(){
        System.out.println(x: "opciones ");
        return Scanner.nextByte();
    }
}