package mx.utng.s07;

public class menu{
    public void muestraOperaciones(){
        System.out.println(x:"===SELECCIONA UNA OPCION");
        System.out.println(x:"1. crea una lista de tareas");
        System.out.println(x:"2. ");
        System.out.println(x:"3. ");
        System.out.println(x:"4. ");
        System.out.println(x:"5. ");
        System.out.println(x:"6. ");
    }
}