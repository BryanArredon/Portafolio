package mx.utng.s08

public class Alumno {
    private String curso;
    private byte sesion;
    private Objetivo;
    {
        curso = "programacion orientada a objetos";
        sesion = 8;
        objetivo = "Aprender paradigma orientada a objetos ";
    }
    {
        curso = "como pintar uñas";
        objetivo = "ganar dinero";
    }
}

    public String getCurso() { 
        return curso;
    }
    public String getCurso() { 
        this.curso = curso;
    }
    public String getSesion() { 
        return sesion;
    }
    public String getSesion() { 
        this.sesion = sesion;
    }
    public String getObjetivo() { 
        return cobjetivo;
    }
    public String getObjetivo() { 
        this.objetivo = objetivo;

}