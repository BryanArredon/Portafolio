public class BloquesInicializacion {
    public static void mail(String[] args){
        Alumno alumno = new Alumno();
        System.out.println(alumno.getCurso());
        System.out.println(alumno.getSesion());
        System.out.println(alumno.getObjetivo());
        
    }

}